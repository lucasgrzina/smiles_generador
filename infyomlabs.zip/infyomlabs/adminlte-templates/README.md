AdminLTE templates for InfyOm Laravel Generator
================================================

Installation steps are located [here](http://labs.infyom.com/laravelgenerator/docs/master/adminlte-templates)
