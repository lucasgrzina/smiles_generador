<?php

namespace Tests;

class DemoTest extends \PHPUnit_Framework_TestCase
{
    public function testSomethingIsTrue()
    {
        $this->assertTrue(true);
    }
}
